from utlib.numbers import sum_digit

print(sum_digit(10, 15))